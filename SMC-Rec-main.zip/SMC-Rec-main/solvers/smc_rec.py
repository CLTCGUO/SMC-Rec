from __future__ import annotations

import os
import pickle
from shutil import copyfile
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import topk as torch_topk

from datasets import EvalDataset, SMCTrainDataset
from models import SMCRec
from tools.utils import init_eval_dataloader, init_train_dataloader

from .base import BaseSolver

__all__ = (
    'SMCRecSolver',
)


class SMCRecSolver(BaseSolver):
    """Solver for SMC-Rec.

    Training objective:
      L = L_next
        + lambda_future * L_pyramid_future
        + lambda_contrast * L_future_contrast
        + lambda_divergence * L_intra_pyramid_divergence_neg
        + lambda_consensus * L_consensus_distill
        + lambda_spectral * L_spectral

    Inference uses only the main forward logits, so future/contrastive/distillation modules
    add no online latency.
    """

    def init_criterion(self) -> None:
        self.ce_none = nn.CrossEntropyLoss(reduction='none')
        self.ce_mean = nn.CrossEntropyLoss()

    def init_dataloader(self) -> None:
        C = self.config
        CD = C['dataloader']
        self.train_dataset = SMCTrainDataset(
            name=C['dataset'],
            sequence_len=CD['sequence_len'],
            future_steps=CD.get('future_steps', C.get('model', {}).get('future_steps', 3)),
            random_cut_prob=CD['random_cut_prob'],
            replace_user_prob=CD['replace_user_prob'],
            replace_item_prob=CD['replace_item_prob'],
            train_num_negatives=CD['train_num_negatives'],
            random_seed=CD['random_seed'],
        )
        self.valid_dataset = EvalDataset(
            name=C['dataset'],
            target='valid',
            sequence_len=CD['sequence_len'],
            valid_num_negatives=CD['valid_num_negatives'],
            random_seed=CD['random_seed'],
        )
        self.test_dataset = EvalDataset(
            name=C['dataset'],
            target='test',
            sequence_len=CD['sequence_len'],
            valid_num_negatives=CD.get('valid_num_negatives', 100),
            random_seed=CD.get('random_seed', None),
        )
        self.train_dataloader = init_train_dataloader(self.train_dataset, C)
        self.valid_dataloader = init_eval_dataloader(self.valid_dataset, C)
        self.test_dataloader = init_eval_dataloader(self.test_dataset, C)

    def _load_optional_semantic_embeddings(self, data_dir: str, num_items: int) -> Optional[np.ndarray]:
        """Load optional item semantic embeddings.

        Supported filenames under data/<dataset>/:
          - semantic_embeddings.pkl
          - item_semantic_embeddings.pkl
          - llm_item_embeddings.pkl
          - fm_item_embeddings.pkl

        The matrix can be shaped as (num_items, d) or (num_items + 1, d). If row 0 is
        missing, a zero padding row is prepended automatically.
        """
        candidates = [
            'semantic_embeddings.pkl',
            'item_semantic_embeddings.pkl',
            'llm_item_embeddings.pkl',
            'fm_item_embeddings.pkl',
        ]
        for fname in candidates:
            path = os.path.join(data_dir, fname)
            if not os.path.isfile(path):
                continue
            with open(path, 'rb') as fp:
                emb = pickle.load(fp)
            emb = np.asarray(emb, dtype=np.float32)
            if emb.ndim != 2:
                raise ValueError(f"{path} must be a 2-D embedding matrix, got shape {emb.shape}")
            if emb.shape[0] == num_items:
                emb = np.vstack([np.zeros((1, emb.shape[1]), dtype=np.float32), emb])
            elif emb.shape[0] < num_items + 1:
                pad = np.zeros((num_items + 1 - emb.shape[0], emb.shape[1]), dtype=np.float32)
                emb = np.vstack([emb, pad])
            elif emb.shape[0] > num_items + 1:
                emb = emb[:num_items + 1]
            self.logger.info(f"loaded semantic embeddings from {path} with shape {emb.shape}")
            return emb
        self.logger.info("no semantic embedding file found; SMC-Rec will use item attributes as semantic memory fallback")
        return None

    def init_model(self) -> None:
        C = self.config
        CM = C['model']
        CD = C['dataloader']
        self.sequence_len = CD['sequence_len']
        dataset_dir = os.path.join(C['envs']['DATA_ROOT'], C['dataset'])

        with open(os.path.join(dataset_dir, 'uid2uindex.pkl'), 'rb') as fp:
            self.uid2uindex = pickle.load(fp)
            self.num_users = len(self.uid2uindex)
        with open(os.path.join(dataset_dir, 'iid2iindex.pkl'), 'rb') as fp:
            self.iid2iindex = pickle.load(fp)
            self.num_items = len(self.iid2iindex)
        with open(os.path.join(dataset_dir, 'ifeatures.pkl'), 'rb') as fp:
            ifeatures = pickle.load(fp)

        if type(CM.get('num_known_item', None)) is float:
            num_known_item = int(self.num_items * CM['num_known_item'])
        else:
            num_known_item = CM.get('num_known_item', None)

        semantic_embeddings = None
        if CM.get('use_semantic_memory', True):
            semantic_embeddings = self._load_optional_semantic_embeddings(dataset_dir, self.num_items)

        self.model = SMCRec(
            sequence_len=self.sequence_len,
            num_items=self.num_items,
            num_users=self.num_users,
            ifeatures=ifeatures,
            ifeature_dim=ifeatures.shape[1],
            icontext_dim=self.train_dataset.icontext_dim,  # type: ignore
            hidden_dim=CM['hidden_dim'],
            num_known_item=num_known_item,
            dropout_prob=CM['dropout_prob'],
            random_seed=CM.get('random_seed', None),
            num_conv_heads=CM.get('num_conv_heads', 1),
            conv_params=CM.get('conv_params', [[2, 2], [5, 5], [7, 7]]),
            semantic_embeddings=semantic_embeddings,
            use_semantic_memory=CM.get('use_semantic_memory', True),
        ).to(self.device)

    def _batch_to_device(self, batch: Dict) -> Dict:
        return {k: v.to(self.device) if hasattr(v, 'to') else v for k, v in batch.items()}

    def calculate_forward(self, batch, return_aux: bool = False):
        batch = self._batch_to_device(batch)
        return self.model(
            batch['uindex'],
            batch['profile_tokens'],
            batch['profile_icontexts'],
            batch['extract_tokens'],
            batch['extract_icontexts'],
            return_aux=return_aux,
        )

    def _prediction_uncertainty_weight(self, logits: torch.Tensor) -> torch.Tensor:
        CM = self.config['model']
        tau = float(CM.get('future_uncertainty_tau', 1.0))
        with torch.no_grad():
            prob = F.softmax(logits, dim=1).clamp_min(1e-12)
            entropy = -(prob * prob.log()).sum(dim=1)
            entropy = entropy / max(float(np.log(logits.size(1))), 1e-6)
            weight = torch.exp(-entropy / max(tau, 1e-6))
        return weight

    def _future_supervision_loss(self, out: Dict, batch: Dict, uncertainty_weight: torch.Tensor) -> torch.Tensor:
        CM = self.config['model']
        future_steps = int(CM.get('future_steps', batch['future_tokens'].size(1)))
        if future_steps <= 0 or 'future_tokens' not in batch:
            return out['logits'].new_zeros(())

        future_tokens = batch['future_tokens'][:, :future_steps]
        future_icontexts = batch['future_icontexts'][:, :future_steps, :]
        future_mask = batch['future_mask'][:, :future_steps]
        negatives = batch['extract_tokens'][:, 1:]
        negative_icontexts = batch['extract_icontexts'][:, 1:, :]
        labels = torch.zeros(batch['uindex'].size(0), dtype=torch.long, device=self.device)

        level_reps = out['level_reps']
        if not level_reps:
            level_reps = [out['user_repr']]

        loss_sum = out['logits'].new_zeros(())
        denom = out['logits'].new_zeros(())
        for k in range(future_steps):
            mask_k = future_mask[:, k].float()
            if torch.sum(mask_k) <= 0:
                continue
            level_idx = min(len(level_reps) - 1, int(round((k + 1) * (len(level_reps) - 1) / max(future_steps, 1))))
            user_repr_k = level_reps[level_idx]
            cand_tokens = torch.cat([future_tokens[:, k:k + 1], negatives], dim=1)
            cand_icontexts = torch.cat([future_icontexts[:, k:k + 1, :], negative_icontexts], dim=1)
            logits_k = self.model.score_candidates(
                user_repr_k,
                batch['uindex'],
                cand_tokens,
                cand_icontexts,
                out['last_icontext'],
            )
            ce_k = self.ce_none(logits_k, labels)
            step_decay = float(CM.get('future_step_decay', 0.9)) ** k
            w = uncertainty_weight * mask_k * step_decay
            loss_sum = loss_sum + torch.sum(ce_k * w)
            denom = denom + torch.sum(w).clamp_min(1e-6)
        return loss_sum / denom.clamp_min(1e-6)

    def _future_contrastive_loss(self, out: Dict, batch: Dict) -> torch.Tensor:
        CM = self.config['model']
        future_mask = batch.get('future_mask', None)
        if future_mask is None or torch.sum(future_mask) <= 0:
            return out['logits'].new_zeros(())
        valid = future_mask.sum(dim=1) > 0
        if valid.sum() < 2:
            return out['logits'].new_zeros(())

        future_repr = self.model.encode_candidates(
            batch['uindex'],
            batch['future_tokens'],
            batch['future_icontexts'],
            out['last_icontext'],
        )
        mask = future_mask.unsqueeze(-1).float()
        horizon = (future_repr * mask).sum(dim=1) / mask.sum(dim=1).clamp_min(1e-6)
        z_user = self.model.future_user_projector(out['user_repr'])
        z_future = self.model.future_item_projector(horizon.detach())
        z_user = F.normalize(z_user[valid], dim=-1)
        z_future = F.normalize(z_future[valid], dim=-1)
        temp = float(CM.get('contrastive_temperature', 0.2))
        sim = z_user.matmul(z_future.t()) / max(temp, 1e-6)
        labels = torch.arange(sim.size(0), device=self.device)
        return self.ce_mean(sim, labels)

    def _divergence_consensus_loss(self, out: Dict) -> Dict[str, torch.Tensor]:
        CM = self.config['model']
        logits = out['logits']
        level_logits = out.get('level_logits', [])
        if not level_logits:
            zero = logits.new_zeros(())
            return {'divergence': zero, 'consensus': zero}

        stacked = torch.stack(level_logits + [logits], dim=0)
        divergence = stacked.var(dim=0, unbiased=False).detach()
        neg_logits = logits[:, 1:]
        pos_logits = logits[:, 0]
        if neg_logits.numel() == 0:
            div_loss = logits.new_zeros(())
        else:
            alpha = float(CM.get('divergence_temperature', 1.0))
            weights = F.softmax(divergence[:, 1:] * alpha, dim=1).detach()
            hard_neg = torch.sum(weights * neg_logits, dim=1)
            div_loss = F.softplus(hard_neg - pos_logits).mean()

        teacher_logits = stacked.mean(dim=0).detach()
        kd_temp = float(CM.get('consensus_temperature', 2.0))
        consensus = F.kl_div(
            F.log_softmax(logits / kd_temp, dim=1),
            F.softmax(teacher_logits / kd_temp, dim=1),
            reduction='batchmean',
        ) * (kd_temp ** 2)
        return {'divergence': div_loss, 'consensus': consensus}

    def calculate_loss(self, batch):
        batch = self._batch_to_device(batch)
        label = batch['label'].long()
        out = self.model(
            batch['uindex'],
            batch['profile_tokens'],
            batch['profile_icontexts'],
            batch['extract_tokens'],
            batch['extract_icontexts'],
            return_aux=True,
        )

        CM = self.config['model']
        weights = CM.get('loss_weights', {})
        main_loss = self.ce_mean(out['logits'], label)
        uncertainty_weight = self._prediction_uncertainty_weight(out['logits'])
        future_loss = self._future_supervision_loss(out, batch, uncertainty_weight)
        contrast_loss = self._future_contrastive_loss(out, batch)
        dc_losses = self._divergence_consensus_loss(out)
        spectral_loss = out['spectral_loss']

        total = main_loss
        total = total + float(weights.get('future', 0.2)) * future_loss
        total = total + float(weights.get('contrast', 0.05)) * contrast_loss
        total = total + float(weights.get('divergence', 0.1)) * dc_losses['divergence']
        total = total + float(weights.get('consensus', 0.05)) * dc_losses['consensus']
        total = total + float(weights.get('spectral', 1e-3)) * spectral_loss
        return total

    def calculate_rankers(self, batch):
        logits = self.calculate_forward(batch, return_aux=False)
        _, rankers = torch_topk(logits, self.max_top_k, dim=1)
        return rankers

    def backup(self):
        copyfile('models/smc_rec.py', f'{self.data_dir}/smc_rec_model.py')
        copyfile('solvers/smc_rec.py', f'{self.data_dir}/smc_rec_solver.py')
        copyfile('datasets.py', f'{self.data_dir}/datasets.py')

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor, LongTensor

from tools.utils import fix_random_seed
from .layers import LayerNorm
from .encoders import ConvItemEncoder

__all__ = ("SMCRec",)


class SpectralSemanticAdapter(nn.Module):
    """Semantic-memory adapter with lightweight spectral regularization.

    This module is intentionally usable with or without offline LLM/FM item embeddings.
    If semantic embeddings are provided, they are projected into the ConvRec hidden space.
    If they are not provided, the model falls back to the frozen attribute feature vector
    and still applies the same geometry-balancing regularizer.

    The regularizer discourages a batch of semantic memory vectors from collapsing into a
    few dominant directions. It is not a hard whitening transform; the loss is soft and
    trainable, which is safer for collaborative signals.
    """

    def __init__(
        self,
        semantic_dim: int,
        hidden_dim: int,
        dropout: float = 0.1,
        spectral_temperature: float = 1.0,
    ) -> None:
        super().__init__()
        self.semantic_dim = semantic_dim
        self.hidden_dim = hidden_dim
        self.spectral_temperature = spectral_temperature
        self.proj = nn.Sequential(
            nn.LayerNorm(semantic_dim),
            nn.Linear(semantic_dim, hidden_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
        )
        self.semantic_gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Sigmoid(),
        )

    def forward(self, base_memory: Tensor, semantic_memory: Tensor, mask: Tensor) -> Tuple[Tensor, Tensor]:
        semantic = self.proj(semantic_memory)
        gate = self.semantic_gate(torch.cat([base_memory, semantic], dim=-1))
        fused = base_memory + gate * semantic
        fused = fused * mask
        spectral_loss = self.spectral_loss(semantic, mask)
        return fused, spectral_loss

    def spectral_loss(self, semantic: Tensor, mask: Tensor) -> Tensor:
        """Soft anisotropy penalty on active semantic vectors.

        It penalizes off-diagonal covariance and variance concentration. This approximates
        the ACE-style goal of controlling anisotropy without requiring a global SVD during
        every training step.
        """
        active = mask.squeeze(-1) > 0
        if active.sum() < 4:
            return semantic.new_zeros(())
        x = semantic[active]
        x = F.layer_norm(x, (x.size(-1),))
        x = x - x.mean(dim=0, keepdim=True)
        denom = max(int(x.size(0)) - 1, 1)
        cov = x.transpose(0, 1).matmul(x) / denom
        diag = torch.diagonal(cov)
        off_diag = cov - torch.diag_embed(diag)
        off_loss = off_diag.pow(2).mean()
        diag_loss = (diag / (diag.mean().detach() + 1e-6) - 1.0).pow(2).mean()
        return off_loss + 0.1 * diag_loss


class SemanticEmbeddingCache(nn.Module):
    """Frozen item-level semantic embedding cache.

    Expected indexing convention is identical to ConvRec: row 0 is padding, item ids are
    positive integer indices. The solver pads/truncates the numpy matrix before passing it.
    """

    def __init__(self, embeddings: np.ndarray, fallback_dim: Optional[int] = None) -> None:
        super().__init__()
        if embeddings is None:
            raise ValueError("embeddings must not be None")
        tensor = torch.as_tensor(embeddings, dtype=torch.float32)
        self.embedding = nn.Embedding.from_pretrained(tensor, freeze=True, padding_idx=0)
        self.output_dim = int(tensor.size(1))
        self.fallback_dim = fallback_dim

    def forward(self, tokens: LongTensor) -> Tensor:
        max_index = self.embedding.num_embeddings - 1
        safe_tokens = tokens.clamp(min=0, max=max_index)
        return self.embedding(safe_tokens)


class AdaptivePyramidConvBlock(nn.Module):
    """A single uncertainty-adaptive down-scaling convolution block."""

    def __init__(
        self,
        hidden_dim: int,
        num_heads: int,
        kernel_size: int,
        stride: int,
        dropout: float,
    ) -> None:
        super().__init__()
        assert hidden_dim % num_heads == 0, "hidden_dim must be divisible by num_heads"
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        self.kernel_size = kernel_size
        self.stride = stride

        self.head_convs = nn.ModuleList([
            nn.Conv1d(self.head_dim, self.head_dim, kernel_size=kernel_size, stride=stride)
            for _ in range(num_heads)
        ])
        self.out_linear = nn.Linear(hidden_dim, hidden_dim)
        self.pool = nn.AvgPool1d(kernel_size=kernel_size, stride=stride)
        self.uncertainty_pool = nn.AvgPool1d(kernel_size=kernel_size, stride=stride)
        self.uncertainty_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2 if hidden_dim >= 2 else hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim // 2 if hidden_dim >= 2 else hidden_dim, 1),
        )
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = LayerNorm(hidden_dim)
        self.alpha_pool = nn.Parameter(torch.tensor(0.5))
        self.alpha_prev = nn.Parameter(torch.tensor(0.5))

    def _conv(self, x: Tensor) -> Tensor:
        bsz = x.size(0)
        xh = x.view(bsz, -1, self.num_heads, self.head_dim).transpose(1, 2)
        outs = []
        for h, conv in enumerate(self.head_convs):
            head = xh[:, h].transpose(1, 2)
            outs.append(conv(head).transpose(1, 2))
        y = torch.cat(outs, dim=-1)
        return self.out_linear(y)

    def forward(self, x: Tensor, prev_residual: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        # x: (B, L, D). Padding is handled outside the block.
        pooled = self.pool(x.transpose(1, 2)).transpose(1, 2)
        prev_pooled = self.pool(prev_residual.transpose(1, 2)).transpose(1, 2)
        conv = self._conv(x)

        # Local uncertainty is estimated before down-scaling. High uncertainty keeps more
        # pooled/raw memory; low uncertainty trusts convolutional compression more.
        token_unc = torch.sigmoid(self.uncertainty_head(x)).transpose(1, 2)  # (B, 1, L)
        unc = self.uncertainty_pool(token_unc).transpose(1, 2)               # (B, L', 1)
        mixed = (1.0 - unc) * conv + unc * pooled
        mixed = F.gelu(mixed)
        mixed = self.dropout(mixed)
        out = self.layer_norm(mixed + self.alpha_pool * pooled + self.alpha_prev * prev_pooled)
        return out, out, unc


class UncertaintyAdaptivePyramidConv(nn.Module):
    """Hierarchical convolution encoder that exposes multi-scale representations."""

    def __init__(
        self,
        hidden_dim: int,
        num_heads: int,
        conv_params: List[List[int]],
        input_length: int,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.blocks = nn.ModuleList()
        self.padding_params: List[int] = []
        current_length = input_length
        for kernel_size, stride in conv_params:
            if current_length >= kernel_size:
                remainder = (current_length - kernel_size) % stride
                pad = 0 if remainder == 0 else stride - remainder
            else:
                pad = kernel_size - current_length
            self.padding_params.append(int(pad))
            self.blocks.append(AdaptivePyramidConvBlock(hidden_dim, num_heads, kernel_size, stride, dropout))
            current_length = (current_length + pad - kernel_size) // stride + 1
        self.collapse = nn.AdaptiveAvgPool1d(1)

    def forward(self, x: Tensor) -> Tuple[Tensor, List[Tensor], List[Tensor]]:
        level_reps: List[Tensor] = []
        uncertainties: List[Tensor] = []
        prev_residual = x
        for block, pad in zip(self.blocks, self.padding_params):
            if pad > 0:
                x = F.pad(x.transpose(1, 2), (pad, 0)).transpose(1, 2)
                prev_residual = F.pad(prev_residual.transpose(1, 2), (pad, 0)).transpose(1, 2)
            x, prev_residual, unc = block(x, prev_residual)
            level_rep = self.collapse(x.transpose(1, 2)).squeeze(-1)
            level_reps.append(level_rep)
            uncertainties.append(unc)
        final = self.collapse(x.transpose(1, 2)).squeeze(-1)
        return final, level_reps, uncertainties


class SMCRec(nn.Module):
    """Spectral Semantic Memory Convolution for attribute-aware SR.

    Major extensions over ConvRec:
    1. spectral semantic memory fusion for item/attribute/context sequences;
    2. uncertainty-adaptive pyramid convolution instead of fixed compression only;
    3. multi-scale level representations for future supervision and divergence-consensus
       negative training in the solver.
    """

    def __init__(
        self,
        sequence_len: int,
        num_items: int,
        num_users: int,
        ifeatures: np.ndarray,
        ifeature_dim: int,
        icontext_dim: int,
        hidden_dim: int = 256,
        num_known_item: Optional[int] = None,
        dropout_prob: float = 0.1,
        random_seed: Optional[int] = None,
        num_conv_heads: int = 1,
        conv_params: List[List[int]] = [[2, 2], [5, 5], [7, 7]],
        semantic_embeddings: Optional[np.ndarray] = None,
        use_semantic_memory: bool = True,
    ) -> None:
        super().__init__()
        self.sequence_len = sequence_len
        self.num_items = num_items
        self.num_users = num_users
        self.ifeature_dim = ifeature_dim
        self.icontext_dim = icontext_dim
        self.hidden_dim = hidden_dim
        self.num_known_item = num_known_item
        self.dropout_prob = dropout_prob
        self.random_seed = random_seed
        self.num_conv_heads = num_conv_heads
        self.conv_params = conv_params
        self.use_semantic_memory = use_semantic_memory

        if random_seed is not None:
            fix_random_seed(random_seed)

        self.item_encoder = ConvItemEncoder(
            sequence_len=sequence_len,
            num_items=num_items,
            num_users=num_users,
            ifeatures=ifeatures,
            ifeature_dim=ifeature_dim,
            icontext_dim=icontext_dim,
            hidden_dim=hidden_dim,
            num_known_item=num_known_item,
            random_seed=random_seed,
            dropout_prob=dropout_prob,
        )

        if semantic_embeddings is not None:
            self.semantic_cache = SemanticEmbeddingCache(semantic_embeddings)
            semantic_dim = self.semantic_cache.output_dim
            self.semantic_from_features = None
        else:
            self.semantic_cache = None
            semantic_dim = ifeature_dim
            self.semantic_from_features = nn.Identity()

        self.semantic_adapter = SpectralSemanticAdapter(
            semantic_dim=semantic_dim,
            hidden_dim=hidden_dim,
            dropout=dropout_prob,
        )

        self.item_layernorm = LayerNorm(hidden_dim + 3)
        self.memory_in = nn.Sequential(
            nn.Linear(hidden_dim + 3, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout_prob),
            LayerNorm(hidden_dim),
        )

        self.candidate_layernorm = LayerNorm(hidden_dim + 3)
        self.candidate_in = nn.Sequential(
            nn.Linear(hidden_dim + 3, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout_prob),
            LayerNorm(hidden_dim),
        )

        self.user_context_layer = nn.Linear(20, hidden_dim)
        self.context_gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Sigmoid(),
        )

        self.pyramid = UncertaintyAdaptivePyramidConv(
            hidden_dim=hidden_dim,
            num_heads=num_conv_heads,
            conv_params=conv_params,
            input_length=sequence_len,
            dropout=dropout_prob,
        )

        # Future and contrastive heads are trained only by the solver. They add no inference
        # overhead because calculate_rankers calls forward() without auxiliary losses.
        num_levels = max(1, len(conv_params))
        self.level_projectors = nn.ModuleList([nn.Linear(hidden_dim, hidden_dim) for _ in range(num_levels)])
        self.future_user_projector = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))
        self.future_item_projector = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))

    def _semantic_lookup(self, tokens: LongTensor) -> Tensor:
        if self.semantic_cache is not None:
            return self.semantic_cache(tokens)
        # fallback: frozen raw attributes become semantic memory when no external LLM/FM
        # embeddings are available.
        ifeatures = self.item_encoder.ifeature_cache(tokens.clamp(min=0, max=self.item_encoder.ifeature_cache.num_embeddings - 1))
        return ifeatures

    def _time_interval(self, icontexts: Tensor) -> Tensor:
        # Only the first three context fields are treated as temporal components, following
        # the original ConvRec implementation.
        temporal = icontexts[:, :, :3]
        if temporal.size(1) <= 1:
            return torch.zeros_like(temporal)
        interval = torch.diff(temporal, dim=1)
        zero = torch.zeros(temporal.size(0), 1, temporal.size(2), device=temporal.device, dtype=temporal.dtype)
        return torch.cat([zero, interval], dim=1)

    def encode_profile(
        self,
        user_index: Tensor,
        profile_tokens: LongTensor,
        profile_icontexts: Tensor,
    ) -> Dict[str, object]:
        mask = (profile_tokens > 0).unsqueeze(-1).float()
        base, _, icontexts, users_vector = self.item_encoder(
            user_index,
            profile_tokens,
            profile_icontexts,
            item_type="profile",
        )
        time_gap = self._time_interval(icontexts)
        base_with_time = torch.cat([base, time_gap], dim=-1)
        base_memory = self.memory_in(self.item_layernorm(F.gelu(base_with_time)))
        base_memory = base_memory * mask

        spectral_loss = base_memory.new_zeros(())
        if self.use_semantic_memory:
            semantic_raw = self._semantic_lookup(profile_tokens)
            base_memory, spectral_loss = self.semantic_adapter(base_memory, semantic_raw, mask)

        user_context = self.user_context_layer(users_vector).unsqueeze(1).repeat(1, base_memory.size(1), 1)
        gate = self.context_gate(torch.cat([base_memory, user_context], dim=-1))
        memory = (base_memory + gate * user_context) * mask

        final_user, level_reps, uncertainties = self.pyramid(memory)
        return {
            "user_repr": final_user,
            "level_reps": level_reps,
            "uncertainties": uncertainties,
            "spectral_loss": spectral_loss,
            "last_icontext": icontexts[:, -1:, :3],
            "mask": mask,
        }

    def encode_candidates(
        self,
        user_index: Tensor,
        candidate_tokens: LongTensor,
        candidate_icontexts: Tensor,
        last_profile_icontext: Tensor,
    ) -> Tensor:
        base, _, cxt, _ = self.item_encoder(
            user_index,
            candidate_tokens,
            candidate_icontexts,
            item_type="extract",
        )
        target_temporal = cxt[:, :, :3]
        target_diff = target_temporal - last_profile_icontext
        cand = torch.cat([base, target_diff], dim=-1)
        cand = self.candidate_in(self.candidate_layernorm(F.gelu(cand)))
        if self.use_semantic_memory:
            mask = (candidate_tokens > 0).unsqueeze(-1).float()
            semantic_raw = self._semantic_lookup(candidate_tokens)
            cand, _ = self.semantic_adapter(cand, semantic_raw, mask)
        return cand

    @staticmethod
    def score(user_repr: Tensor, candidate_repr: Tensor) -> Tensor:
        return torch.matmul(candidate_repr, user_repr.unsqueeze(-1)).squeeze(-1)

    def score_candidates(
        self,
        user_repr: Tensor,
        user_index: Tensor,
        candidate_tokens: LongTensor,
        candidate_icontexts: Tensor,
        last_profile_icontext: Tensor,
    ) -> Tensor:
        candidate_repr = self.encode_candidates(user_index, candidate_tokens, candidate_icontexts, last_profile_icontext)
        return self.score(user_repr, candidate_repr)

    def forward(
        self,
        user_index: Tensor,
        profile_tokens: LongTensor,
        profile_icontexts: Tensor,
        extract_tokens: LongTensor,
        extract_icontexts: Tensor,
        return_aux: bool = False,
    ):
        profile_out = self.encode_profile(user_index, profile_tokens, profile_icontexts)
        user_repr = profile_out["user_repr"]
        level_reps = profile_out["level_reps"]
        last_icontext = profile_out["last_icontext"]
        candidate_repr = self.encode_candidates(user_index, extract_tokens, extract_icontexts, last_icontext)
        logits = self.score(user_repr, candidate_repr)

        if not return_aux:
            return logits

        level_logits: List[Tensor] = []
        for idx, rep in enumerate(level_reps):
            projected = self.level_projectors[min(idx, len(self.level_projectors) - 1)](rep)
            level_logits.append(self.score(projected, candidate_repr))

        return {
            "logits": logits,
            "candidate_repr": candidate_repr,
            "user_repr": user_repr,
            "level_reps": level_reps,
            "level_logits": level_logits,
            "uncertainties": profile_out["uncertainties"],
            "spectral_loss": profile_out["spectral_loss"],
            "last_icontext": last_icontext,
        }

from __future__ import annotations

import argparse
import os
import pickle
from pathlib import Path

import numpy as np


def load_matrix(path: str) -> np.ndarray:
    with open(path, 'rb') as fp:
        obj = pickle.load(fp)
    arr = np.asarray(obj, dtype=np.float32)
    if arr.ndim != 2:
        raise ValueError(f"Expected 2-D matrix, got {arr.shape}")
    return arr


def ace_spectral_shrinkage(x: np.ndarray, out_dim: int, lam: float) -> np.ndarray:
    """ACE-style spectral shrinkage for item semantic initialization.

    E = U S V^T, E_ace = U[:, :k] * sqrt(S^2 / (S^2 + lambda)).
    This reshapes the item-item geometry and controls anisotropy without forcing all
    singular values to be exactly equal.
    """
    x = x.astype(np.float32)
    padding = None
    if np.allclose(x[0], 0.0):
        padding = x[:1]
        x_body = x[1:]
    else:
        x_body = x
    x_body = x_body - x_body.mean(axis=0, keepdims=True)
    u, s, _ = np.linalg.svd(x_body, full_matrices=False)
    k = min(out_dim, u.shape[1])
    shrink = np.sqrt((s[:k] ** 2) / (s[:k] ** 2 + lam)).astype(np.float32)
    y = u[:, :k] * shrink[None, :]
    if k < out_dim:
        y = np.concatenate([y, np.zeros((y.shape[0], out_dim - k), dtype=np.float32)], axis=1)
    if padding is not None:
        y = np.vstack([np.zeros((1, y.shape[1]), dtype=np.float32), y])
    return y.astype(np.float32)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help='Path to item embedding pickle, e.g. data/fashion/ifeatures.pkl or LLM embeddings.')
    parser.add_argument('--output', required=True, help='Output pickle path, normally data/<dataset>/semantic_embeddings.pkl')
    parser.add_argument('--out-dim', type=int, default=128)
    parser.add_argument('--lambda', dest='lam', type=float, default=1.0)
    args = parser.parse_args()

    x = load_matrix(args.input)
    y = ace_spectral_shrinkage(x, out_dim=args.out_dim, lam=args.lam)
    Path(os.path.dirname(args.output)).mkdir(parents=True, exist_ok=True)
    with open(args.output, 'wb') as fp:
        pickle.dump(y, fp)
    print(f'Saved spectral semantic embeddings: {args.output}, shape={y.shape}')


if __name__ == '__main__':
    main()

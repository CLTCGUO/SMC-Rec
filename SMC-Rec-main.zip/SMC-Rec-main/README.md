## Rethinking Convolutional Networks for Attribute-Aware Sequential Recommendation

> Shereen Elsayed*, Ngoc Son Le*, Ahmed Rashed, and Lars Schmidt-Thieme<br>
> \* Equal contribution<br>
> Accepted at IJCAI-ECAI 2026

ConvRec is a convolution-based model for attribute- and context-aware sequential recommendation. Instead of relying on self-attention to aggregate the full user sequence, ConvRec uses hierarchical down-scaling convolutional layers to progressively compress a user’s interaction history into a compact sequence representation. The model is evaluated on four Amazon benchmark datasets: `fashion`, `beauty`, `men`, and `game`.

<p align="center">
  <img src="ConvRec.svg" width="750">
</p>

<p align="center">
  <em>Overview of the ConvRec framework.</em>
</p>

## Data

This project uses the data format from the CARCA repository. 

* raw dataset directory: `./raw/`
    * put [CARCA/Data](https://github.com/ahmedrashed-ml/CARCA) as `./raw/CARCA/`
* data directory: `./data/`

Run preprocessing:

```bash
python preprocess.py prepare --dname fashion
python preprocess.py prepare --dname beauty
python preprocess.py prepare --dname men
python preprocess.py prepare --dname game
```


Run the code: 

```bash
python entry.py convrec/men
```

## Citation
```
@inproceedings{elsayed2026convrec,
  title     = {Rethinking Convolutional Networks for Attribute-Aware Sequential Recommendation},
  author    = {Elsayed, Shereen and Le, Ngoc Son and Rashed, Ahmed and Schmidt-Thieme, Lars},
  booktitle = {Proceedings of the Thirty-Fifth International Joint Conference on Artificial Intelligence, IJCAI-ECAI 2026},
  year      = {2026},
  note      = {To appear}
}
```

---

## SMC-Rec: Spectral Semantic Memory Convolution

This package adds a new research prototype based on ConvRec:

**SMC-Rec = Spectral Semantic Memory Convolution for Attribute-Aware Sequential Recommendation**

It implements the innovation plan discussed in this conversation:

1. **Spectral Semantic Memory Encoder**
   - Supports optional offline LLM/FM item embeddings from `data/<dataset>/semantic_embeddings.pkl`.
   - If the file is absent, it falls back to item attribute features, so the code can still run on the original ConvRec data format.
   - Adds a soft spectral regularization loss to mitigate anisotropic semantic-memory collapse.

2. **Uncertainty-Adaptive Pyramid Convolution**
   - Replaces fixed-only hierarchical down-scaling with an uncertainty gate inside every convolution block.
   - High-uncertainty local windows retain more pooled/raw memory; low-uncertainty windows trust convolutional compression more.

3. **Pyramid-Level Future Supervision**
   - The new `SMCTrainDataset` samples an internal pivot from each user sequence.
   - It uses the immediate next item as the main target and later items as K-step future auxiliary targets.
   - Future loss is dynamically weighted by the entropy of the main next-item prediction.

4. **Intra-Pyramid Divergence-Consensus Training**
   - Uses short/mid/long pyramid-level logits as internal views.
   - Mines divergence-aware hard negatives using score variance across pyramid levels.
   - Distills multi-scale consensus back into the final representation via KL divergence.

### New files

```text
models/smc_rec.py                 # New model
solvers/smc_rec.py                # New solver and losses
datasets.py                       # Adds SMCTrainDataset
configs/smc_rec_config.json       # Example config
scripts/build_spectral_semantics.py
```

### How to run

Prepare the original ConvRec/CARCA-format data first:

```bash
python preprocess.py prepare --dname fashion
```

Create a run directory and copy the example config:

```bash
mkdir -p runs/smc_rec/fashion
cp configs/smc_rec_config.json runs/smc_rec/fashion/config.json
```

Then run:

```bash
python entry.py smc_rec/fashion
```

### Optional: build spectral semantic embeddings

If you already have LLM/FM item embeddings, save them as a pickle matrix and run:

```bash
python scripts/build_spectral_semantics.py \
  --input data/fashion/llm_item_embeddings.pkl \
  --output data/fashion/semantic_embeddings.pkl \
  --out-dim 128 \
  --lambda 1.0
```

For a quick fallback experiment using the original item attributes as semantic input:

```bash
python scripts/build_spectral_semantics.py \
  --input data/fashion/ifeatures.pkl \
  --output data/fashion/semantic_embeddings.pkl \
  --out-dim 128 \
  --lambda 1.0
```

### Suggested ablations

Modify `loss_weights` and `use_semantic_memory` in `configs/smc_rec_config.json`:

```text
w/o semantic memory:      use_semantic_memory = false
w/o future supervision:   loss_weights.future = 0
w/o contrastive learning: loss_weights.contrast = 0
w/o divergence mining:    loss_weights.divergence = 0
w/o consensus distill:    loss_weights.consensus = 0
w/o spectral constraint:  loss_weights.spectral = 0
```
